import numpy as np
from typing import Iterable, Tuple, Union

import torch
from turtledemo.chaos import distance
from tfm_control_ucm.core.grid_env.map import GridMap

class GridLidar:
    """
    A 2D LIDAR sensor that casts multiple rays in a configurable field of view.

    Parameters
    ----------
    num_rays : int
        Number of rays to cast.
    max_range : int
        Maximum number of grid cells each ray can travel.
    fov_rad : float
        Field of view in radians (e.g., pi for a semicircle).
    noise_std : float
        Optional Gaussian noise added to distance readings.
    """

    def __init__(
        self,
        *,
        num_rays: int = 10,
        max_range: int = 10,
        fov: float = np.pi,
        noise_std: float = 0.001,
        with_cache: bool = True
    ):
        if not isinstance(num_rays, np.number|int): raise TypeError("The num_rays must be an integer")
        if not isinstance(max_range, np.number|int): raise TypeError("The max_range must be an integer")
        if not isinstance(fov, np.number|float): raise TypeError("The fov must be a float")
        if not isinstance(noise_std, np.number|float): raise TypeError("The noise_std must be a float")
        if not isinstance(with_cache, bool): raise TypeError("The with_cache must be a boolean")

        if num_rays <= 0: raise ValueError("The num_rays must be greater than zero")
        if max_range <= 0: raise ValueError("The max_range must be greater than zero")
        if fov <= 0: raise ValueError("The fov must be greater than zero")
        if noise_std <= 0: raise ValueError("The noise_std must be greater than zero")


        self.num_rays = num_rays
        self.max_range = max_range
        self.fov_rad = fov
        self.noise_std = noise_std
        self.last_results = np.ones((self.num_rays,2))*(-1.0)
        self._scan_cache = {}
        self.with_cache = with_cache

    def _get_state_key(self, position: np.ndarray, orientation: Union[float,np.floating]) -> tuple:
        """Centralice the generation of the cache key."""
        return (int(position[0]), int(position[1])), round(float(orientation), 4)
    
    def get_config(self):
        return {'num_rays':self.num_rays, 'max_range':self.max_range, 'fov': self.fov_rad, 'noise_std': self.noise_std, 'with_cache': self.with_cache}
    
    @classmethod
    def config_keys(cls):
        return ['num_rays', 'max_range', 'fov', 'noise_std', 'with_cache']
    # ------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------
    def scan(
        self,
        gridmap: GridMap,
        position: Union[Iterable[int],np.ndarray],
        orientation: Union[float,np.floating],
    ) :
        """
        Perform a LIDAR scan from the robot's position.

        Returns
        -------
        distances : np.ndarray
            Array of size (num_rays,) with distances to obstacles.
        """
        position = np.asarray(position)

        if position.size != 2: raise ValueError("The position must be of size 2")

        if not np.issubdtype(position.dtype,np.number): raise TypeError("The position must be of type number")

        state_key = self._get_state_key(position, orientation)
        if self.with_cache and state_key in self._scan_cache:
            self.last_results = self._scan_cache[state_key]
            return self.last_results
        
        angles = self._compute_ray_angles(orientation)

        return_values = self._perform_scan(gridmap, position, angles)
        self.last_results = np.array(return_values)
        result = np.array(return_values)

        if  self.with_cache:
            self._scan_cache[state_key] = result
        self.last_results = result

        return result
    
    def _perform_scan(self, gridmap: GridMap, position: np.ndarray, angles: np.ndarray) -> np.ndarray:
        """Helper method to perform the actual scanning logic."""
        return np.array([[self._cast_single_ray(gridmap, position, angle),angle] for angle in angles])
    # ------------------------------------------------------------
    # Ray angle computation
    # ------------------------------------------------------------
    def _compute_ray_angles(self, orientation: Union[float, np.floating]) -> np.ndarray:
        """
        Compute absolute angles (in radians) for each ray based on robot orientation.
        Orientation is one of: N pi/2, E 0, S -pi/2, W pi.
        """

        base_angle = orientation

        # Spread rays evenly across the FOV
        half_fov = self.fov_rad / 2
        return np.linspace(base_angle - half_fov, base_angle + half_fov, self.num_rays)
    # ------------------------------------------------------------
    # Get Grid Point from Ray
    # ------------------------------------------------------------
    def _get_grid_point_from_ray(self, position: np.ndarray, angle_rad: float, distance: float) -> Tuple[int,int]:
        """
        Compute the grid cell coordinates that a ray hits based on its angle and distance.
        """
        dr = np.sin(angle_rad)
        dc = np.cos(angle_rad)

        c, r = position

        rr = int(round(r - dr * distance))
        cc = int(round(c + dc * distance))

        return rr, cc

    # ------------------------------------------------------------
    # Raycasting
    # ------------------------------------------------------------
    def _cast_single_ray(
        self,
        gridmap: GridMap,
        position: np.ndarray,
        angle_rad: float,
    ) -> float:
        """
        Cast a single ray and return the distance to the nearest obstacle.
        """
        dr = np.sin(angle_rad)
        dc = np.cos(angle_rad)

        c, r = position

        for dist in range(1, self.max_range + 1):
            rr = int(round(r - dr * dist))
            cc = int(round(c + dc * dist))
            # rr,cc = self._get_grid_point_from_ray(position, angle_rad, dist)

            if not gridmap.in_bounds(rr, cc):
                return dist  # hit boundary

            if gridmap.is_obstacle(rr, cc):
                return dist  # hit obstacle

        return -1.0


class GridLidar_2D(GridLidar):
    """
    A 2D LIDAR sensor that casts multiple rays in a configurable field of view.
    Returns a 2D local occupancy grid image.
    """

    def __init__(
        self,
        *,
        num_rays: int = 10,
        max_range: int = 10,
        fov: float = np.pi,
        noise_std: float = 0.001,
        with_cache: bool = True
    ):
        super().__init__(num_rays=num_rays, max_range=max_range, fov=fov, noise_std=noise_std, with_cache=with_cache)

    @classmethod
    def config_keys(cls):
        return ['num_rays', 'max_range', 'fov', 'noise_std', 'with_cache']

    def _perform_scan(self, gridmap: GridMap, position: np.ndarray, angles: np.ndarray) -> np.ndarray:
        """
        Sobrescribe la lógica de escaneo para generar la matriz 2D.
        """
        grid_size = 2 * self.max_range + 1
        lidar_image = np.full((grid_size, grid_size), -1, dtype=np.int8)
        
        center = self.max_range
        lidar_image[center, center] = 0

        # Esta es la versión de bucle estándar. Si aplicaste la vectorización 
        # que discutimos antes, el código vectorizado iría exactamente aquí.
        for angle in angles:
            hit_distance = self._cast_single_ray(gridmap, position, angle)
            
            dr = np.sin(angle)
            dc = np.cos(angle)
            
            max_dist_to_check = int(hit_distance) if hit_distance > 0 else self.max_range
            
            for dist in range(1, max_dist_to_check + 1):
                rr_local = center + int(round(-dr * dist))
                cc_local = center + int(round(dc * dist))
                
                if 0 <= rr_local < grid_size and 0 <= cc_local < grid_size:
                    if dist == hit_distance:
                        lidar_image[rr_local, cc_local] = 1
                    else:
                        if lidar_image[rr_local, cc_local] != 1:
                            lidar_image[rr_local, cc_local] = 0

        return lidar_image
    
