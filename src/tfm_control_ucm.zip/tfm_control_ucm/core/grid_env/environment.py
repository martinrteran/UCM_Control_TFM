"""
environment.py

Gymnasium environment integrating:
- GridMap
- Robot (with orientation)
- Lidar sensor

Author: Martin
"""

from __future__ import annotations
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Optional, Union, Iterable, Dict

from .map import GridMap
from .robot import GridRobot
from .sensor import GridLidar, GridLidar_2D
import torch
from torchrl.envs import EnvBase
from torchrl.data import (
    Bounded,        # replaces BoundedTensorSpec
    Categorical,    # replaces DiscreteTensorSpec
    Composite,      # replaces CompositeSpec
    Unbounded,      # replaces UnboundedContinuousTensorSpec
)
from tensordict import TensorDict

from tfm_control_ucm.renderers.grid_renderer import PygameRenderer, PygameRenderer_Image_Lidar

class Grid_Robot_Env(gym.Env):
    """
    Docstring for Robot_Grid_Env
    
    """
    metadata = {"render_modes": ["human"], "render_fps": 10}
    _min_num_rays = 8
    _max_noise_std = 0.5
    _max_range = 100
    _min_separation_distance = 5
    
    def __init__(self, *,
                map: GridMap,
                robot: GridRobot,
                lidar_config: Optional[Dict] = None,
                max_iteration_steps: Union[int,np.integer] = 10_000,
                render_mode: Optional[str] = None,
                cell_size: int = 32
                ) -> None:
        if not isinstance(map, GridMap): raise TypeError("The map must be of type GridMap")
        if not isinstance(robot, GridRobot): raise TypeError("The robot must be of type GridRobot")
        if lidar_config: 
            if any(key not in GridLidar.config_keys() for key in lidar_config.keys()): raise ValueError(f"One of the configuration keys for the lidar is not correct. The configuration keys are: {', '.join(GridLidar.config_keys())}")
            elif lidar_config['num_rays'] < self._min_num_rays: raise ValueError(f"The field 'num_rays' (number of rays) must be greater or equal to {self._min_num_rays}")
            elif lidar_config['max_range'] > self._max_range: raise ValueError(f"The field 'max_range' (maximum detection distance) must be less or equal to {self._max_range}")
            elif lidar_config['noise_std'] > self._max_noise_std: raise ValueError(f"The field 'noise_std' (maximum noise standard deviation) must be less or equal to {self._max_noise_std}")

        super().__init__()
        self.map = map
        self.robot = robot
        if not lidar_config:
            self.lidar = GridLidar()
        else:
            self.lidar = GridLidar(**lidar_config)
        self.max_steps = max_iteration_steps
        self.render_mode = render_mode
        
        max_map_distance = np.sqrt(np.sum(np.array(self.map.grid.shape) **2))
        self._map_diagonal = max_map_distance

        self.action_space = spaces.Discrete(3,dtype=np.int8) # One for move foward and bakward and another one for changing orientation
        self.observation_space = spaces.Box( low=np.array([[-1, -np.pi]] * self._min_num_rays + [[0.0, -np.pi]]), high=np.array([[self._max_range, np.pi]] * self._min_num_rays + [[max_map_distance, np.pi]]))

        self.steps = 0
        self.cell_size = cell_size
    
    def get_observation_shape(self):
        return self.observation_space.shape
    
    def get_observation_dim(self):
        return np.prod(self.observation_space.shape) # type: ignore
    
    def get_action_dim(self):
        return self.action_space.n # type: ignore
    
    def get_action_shape(self):
        return self.action_space.shape

    def _get_observation(self):
        scanning = self.lidar.scan(self.map, self.robot.position, self.robot.ORIENTATIONS[self.robot.orientation]['angle'])
        
        idx = np.argsort(scanning[:,0])
        scanning = scanning[idx[::-1]] # descending order
        
        top_scanning = scanning[0:self._min_num_rays]
        robot_obs = np.array([self._dist_to_goal(),self._angle_to_goal()])
        
        concated = np.vstack([top_scanning, robot_obs])
        return concated

    def _dist_to_goal(self):
        return np.sqrt(np.sum((self.goal_pos - self.robot.position)**2))    
    
    def _angle_to_goal(self):
        x_diff, y_diff = self.goal_pos - self.robot.position
        return np.atan2(y_diff, x_diff)
    
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)

        height, width = self.map.grid.shape
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            orien = self.robot.ORIENTATIONS_LIST[np.random.randint(0,4)]
            if self.map.is_free(r, c):
                self.robot.reset((c,r),orien)
                isCorrect = True
        
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            self.goal_pos = np.array([c,r])
            dist_to_robot = self._dist_to_goal()
            if self.map.is_free(r, c) and dist_to_robot > self._min_separation_distance:
                isCorrect = True

        self.steps = 0
        self.previous_action = -1 # Do nothing

        obs = self._get_observation()
        info = {}

        return obs, info
    
    def step(self, action: int):
        self.steps += 1
    
        previous_dist2goal = self._dist_to_goal()
        truncated = False
        if action == 0: # Move foward
            moved = self.robot.forward(self.map)
            truncated = not moved
        # elif action == [-1,0]: # Move backward
        #     moved = self.robot.backward(self.map)
        #     terminated = not moved
        elif action == 1: # Rotate left
            self.robot.turn_left()
        else:# elif action == 3: # Rotate right
            self.robot.turn_right()            

        obs = self._get_observation()
        info = {}
        
        dist2goal = obs[-1][0]
        
        mean_dists = np.mean(obs[:-1,0])

        reward = -0.2 if self.previous_action > 0 and action > 0 else -0.01
        reward -= dist2goal/self._map_diagonal
        reward -= mean_dists/self._map_diagonal
        reward += (previous_dist2goal - dist2goal)/self._map_diagonal * 5

        terminated = False
        if dist2goal < 1:
            terminated = True
            reward += 100.0  # Big success reward

        # Replace your reward calculation with:
        truncated = truncated or bool(self.steps >= self.max_steps)
        if truncated:
            reward = -10.0
        
        self.previous_action = action
        
        return obs, reward, terminated, truncated, info
    
    def render(self):
        if self.render_mode != 'human': return
        if not hasattr(self, "renderer"): self.renderer = PygameRenderer(self.map, cell_size=self.cell_size)
        dists = self._get_observation()
        self.renderer.handle_events()
        self.renderer.render(self.robot, self.lidar,dists[:-1,:], self.goal_pos)

class Grid_Robot_Sections_Env(gym.Env):
    """
    Docstring for Robot_Grid_Env
    
    """
    metadata = {"render_modes": ["human"], "render_fps": 10}
    _min_num_rays = 12
    _min_num_sections = 4
    _max_noise_std = 0.5
    _max_range = 100
    _min_separation_distance = 10
    _max_previous_actions = 5
    _previous_actions: np.ndarray = np.array([])
    
    def __init__(self, *,
                map: GridMap,
                robot: GridRobot,
                lidar_config: Optional[Dict] = None,
                max_iteration_steps: Union[int,np.integer] = 10_000,
                render_mode: Optional[str] = None,
                cell_size: int = 32,
                num_sections: int = _min_num_sections
                ) -> None:
        if not isinstance(map, GridMap): raise TypeError("The map must be of type GridMap")
        if not isinstance(robot, GridRobot): raise TypeError("The robot must be of type GridRobot")
        if num_sections < self._min_num_sections and num_sections%4 != 0: raise ValueError(f"The number of sections must be greater or equal to {self._min_num_sections} and a multiple of 4")

        if lidar_config: 
            if any(key not in GridLidar.config_keys() for key in lidar_config.keys()): raise ValueError(f"One of the configuration keys for the lidar is not correct. The configuration keys are: {', '.join(GridLidar.config_keys())}")
            elif lidar_config['num_rays'] < self._min_num_rays: raise ValueError(f"The field 'num_rays' (number of rays) must be greater or equal to {self._min_num_rays}")
            elif lidar_config['max_range'] > self._max_range: raise ValueError(f"The field 'max_range' (maximum detection distance) must be less or equal to {self._max_range}")
            elif lidar_config['noise_std'] > self._max_noise_std: raise ValueError(f"The field 'noise_std' (maximum noise standard deviation) must be less or equal to {self._max_noise_std}")
        
        super().__init__()
        self.map = map
        self.robot = robot
        if not lidar_config:
            self.lidar = GridLidar(num_rays=self._min_num_rays, max_range=self._max_range, noise_std=self._max_noise_std, with_cache=True)
        else:
            self.lidar = GridLidar(**lidar_config)
        self.max_steps = max_iteration_steps
        self.render_mode = render_mode
        
        max_map_distance = np.sqrt(np.sum(np.array(self.map.grid.shape) **2))
        self._map_diagonal = max_map_distance

        self.action_space = spaces.Discrete(3,dtype=np.int8) # One for move foward and bakward and another one for changing orientation
        self.observation_space = spaces.Box( low=np.array([[-1, -np.pi]] * num_sections + [[0.0, -np.pi]]), high=np.array([[self._max_range, np.pi]] * num_sections + [[max_map_distance, np.pi]]))

        self.steps = 0
        self.cell_size = cell_size
        self.num_sections = num_sections

        self.__angle_per_section = 2*np.pi/num_sections;
        self.__start_angle = -self.__angle_per_section/2;
    
    def get_observation_shape(self):
        return self.observation_space.shape
    
    def get_observation_dim(self):
        return np.prod(self.observation_space.shape) # type: ignore
    
    def get_action_dim(self):
        return self.action_space.n # type: ignore
    
    def get_action_shape(self):
        return self.action_space.shape

    def _get_observation(self):
        scanning = self.lidar.scan(self.map, self.robot.position, self.robot.ORIENTATIONS[self.robot.orientation]['angle'])# distances to obstacles and angles to obstacles [[dist, angle],[dist, angle],...]

        # Convert angles to [-pi, pi]
        scanning[scanning[:,1]>np.pi,1] -= 2*np.pi # Convert angles greater than pi to (-pi, pi]
        scanning[scanning[:,1]<=-np.pi,1] += 2*np.pi # Convert negative angles to (-pi, pi]
        top_scanning = np.ones((self.num_sections,2))*(-1.0) # Initialize with -1 (no detection)
        
        for i in range(self.num_sections):
            section_start = self.__start_angle + i*self.__angle_per_section
            section_end = self.__start_angle + (i+1)*self.__angle_per_section

            section_start = section_start + 2*np.pi if section_start <= -np.pi else section_start - 2*np.pi if section_start> np.pi else section_start  
            section_end = section_end + 2*np.pi if section_end <= -np.pi else section_end - 2*np.pi if section_end> np.pi else section_end

            in_section = (scanning[:,1] >= section_start) & (scanning[:,1] < section_end)
            if np.any(in_section):
                closest_idx = np.argmin(scanning[in_section,0]) # Get the index of the closest obstacle in the section
                top_scanning[i,:] = scanning[closest_idx,:] # Take the minimum distance in the section
            else:
                top_scanning[i,0] = self._max_range # If there are no obstacles in the section, we assume the maximum range
                top_scanning[i,1] = (section_start + section_end)/2 # Angle of the center of the section
        
        robot_obs = np.array([self._dist_to_goal(),self._angle_to_goal()])
        
        concated = np.vstack([top_scanning, robot_obs])
        return concated

    def _dist_to_goal(self):
        return np.sqrt(np.sum((self.goal_pos - self.robot.position)**2))    
    
    def _angle_to_goal(self):
        x_diff, y_diff = self.goal_pos - self.robot.position
        return np.atan2(y_diff, x_diff)
    
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)

        height, width = self.map.grid.shape
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            orien = self.robot.ORIENTATIONS_LIST[np.random.randint(0,4)]
            if self.map.is_free(r, c):
                self.robot.reset((c,r),orien)
                isCorrect = True
        
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            self.goal_pos = np.array([c,r])
            dist_to_robot = self._dist_to_goal()
            if self.map.is_free(r, c) and dist_to_robot > self._min_separation_distance:
                isCorrect = True

        self.steps = 0
        self.previous_action = -1 # Do nothing

        obs = self._get_observation()
        info = {}
        self._previous_actions = np.array([]) # Empty it

        return obs, info
    
    def step(self, action: int):
        self.steps += 1
    
        previous_dist2goal = self._dist_to_goal()
        truncated = False
        if action == 0: # Move foward
            moved = self.robot.forward(self.map)
            truncated = not moved
        elif action == 1: # Rotate left
            self.robot.turn_left()
        else:# elif action == 3: # Rotate right
            self.robot.turn_right()            

        obs = self._get_observation()
        info = {}
        
        dist2goal = obs[-1][0]
        
        mean_dists = np.mean(obs[:-1,0]) + 1e-6

        reward = -0.2 if len(self._previous_actions) > 0 and len(self._previous_actions[ self._previous_actions > 0 ]) > self._max_previous_actions/2 else -0.01
        reward -= dist2goal/self._map_diagonal
        reward -= self._map_diagonal/mean_dists
        reward += (previous_dist2goal - dist2goal)/self._map_diagonal * 5

        done = False
        if dist2goal < 1:
            done = True
            reward = 100.0  # Big success reward

        truncated = truncated or bool(self.steps >= self.max_steps)
        if truncated:
            reward -= 50.0
        
        self._previous_actions = np.append(self._previous_actions, action)
        if len(self._previous_actions) > self._max_previous_actions: # Keep only the last 5 actions
            self._previous_actions = self._previous_actions[1:]
        
        return obs, reward, done, truncated, info
    
    def render(self):
        if self.render_mode != 'human': return
        if not hasattr(self, "renderer"): self.renderer = PygameRenderer(self.map, cell_size=self.cell_size)
        dists = self._get_observation()
        self.renderer.handle_events()
        self.renderer.render(self.robot, self.lidar,dists[:-1,:], self.goal_pos)

class Grid_Robot_Env_Image_lidar(gym.Env):
    """
    Docstring for Robot_Grid_Env
    
    """
    metadata = {"render_modes": ["human"], "render_fps": 10}
    _min_num_rays = 50
    _max_noise_std = 0.5
    _max_range = 100
    _min_separation_distance = 5
    _previous_actions: list = []
    _max_previous_actions = 5
    
    def __init__(self, *,
                map: GridMap,
                robot: GridRobot,
                lidar_config: Optional[Dict] = None,
                max_iteration_steps: Union[int,np.integer] = 10_000,
                render_mode: Optional[str] = None,
                cell_size: int = 32
                ) -> None:
        if not isinstance(map, GridMap): raise TypeError("The map must be of type GridMap")
        if not isinstance(robot, GridRobot): raise TypeError("The robot must be of type GridRobot")
        if lidar_config: 
            if any(key not in GridLidar.config_keys() for key in lidar_config.keys()): raise ValueError(f"One of the configuration keys for the lidar is not correct. The configuration keys are: {', '.join(GridLidar.config_keys())}")
            elif lidar_config['num_rays'] < self._min_num_rays: raise ValueError(f"The field 'num_rays' (number of rays) must be greater or equal to {self._min_num_rays}")
            elif lidar_config['max_range'] > self._max_range: raise ValueError(f"The field 'max_range' (maximum detection distance) must be less or equal to {self._max_range}")
            elif lidar_config['noise_std'] > self._max_noise_std: raise ValueError(f"The field 'noise_std' (maximum noise standard deviation) must be less or equal to {self._max_noise_std}")

        super().__init__()
        self.map = map
        self.robot = robot
        if not lidar_config:
            self.lidar = GridLidar_2D()
        else:
            self.lidar = GridLidar_2D(**lidar_config)
        self.max_steps = max_iteration_steps
        self.render_mode = render_mode
        
        max_map_distance = np.sqrt(np.sum(np.array(self.map.grid.shape) **2))
        self._map_diagonal = max_map_distance

        self.action_space = spaces.Discrete(3,dtype=np.int8) # One for move foward and bakward and another one for changing orientation
        grid_size = 2 * self.lidar.max_range + 1;
        self.observation_space = spaces.Dict({
            "lidar": spaces.Box(low=0, high=self.lidar.max_range,
                                 shape=(grid_size, grid_size), dtype=np.int8),
            "robot": spaces.Box(low=np.array([0.0, -np.pi]), 
                    high=np.array([max_map_distance, np.pi]), dtype=np.float32)
        })
        self.observation_space = spaces.Box( low=np.array([[-1, -np.pi]] * self._min_num_rays + [[0.0, -np.pi]]), high=np.array([[self._max_range, np.pi]] * self._min_num_rays + [[max_map_distance, np.pi]]))

        self.steps = 0
        self.cell_size = cell_size
    
    def get_observation_shape(self):
        return self.observation_space.shape
    
    def get_observation_dim(self):
        return np.prod(self.observation_space.shape) # type: ignore
    
    def get_action_dim(self):
        return self.action_space.n # type: ignore
    
    def get_action_shape(self):
        return self.action_space.shape

    def _get_observation(self):
        scanning = self.lidar.scan(self.map, self.robot.position, self.robot.ORIENTATIONS[self.robot.orientation]['angle'])
        
        robot_obs = np.array([self._dist_to_goal(),self._angle_to_goal()])
        
        return {"lidar": scanning, "robot": robot_obs}

    def _dist_to_goal(self):
        return np.sqrt(np.sum((self.goal_pos - self.robot.position)**2))    
    
    def _angle_to_goal(self):
        x_diff, y_diff = self.goal_pos - self.robot.position
        return np.atan2(y_diff, x_diff)
    
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)

        height, width = self.map.grid.shape
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            orien = self.robot.ORIENTATIONS_LIST[np.random.randint(0,4)]
            if self.map.is_free(r, c):
                self.robot.reset((c,r),orien)
                isCorrect = True
        
        isCorrect = False
        while not isCorrect:
            r = np.random.randint(0,height)
            c = np.random.randint(0,width)
            self.goal_pos = np.array([c,r])
            dist_to_robot = self._dist_to_goal()
            if self.map.is_free(r, c) and dist_to_robot > self._min_separation_distance:
                isCorrect = True

        self.steps = 0
        self.previous_action = -1 # Do nothing
        self._previous_actions.clear() # Empty it

        obs = self._get_observation()
        info = {}

        return obs, info
    
    def step(self, action: int):
        self.steps += 1
    
        previous_dist2goal = self._dist_to_goal()
        truncated = False
        if action == 0: # Move foward
            moved = self.robot.forward(self.map)
            truncated = not moved
        elif action == 1: # Rotate left
            self.robot.turn_left()
        else:# elif action == 3: # Rotate right
            self.robot.turn_right()            
        if len(self._previous_actions) >= self._max_previous_actions: # Keep only the last 5 actions
            self._previous_actions.pop(0)
        self._previous_actions.append(action)

        obs = self._get_observation()
        scanning = obs["lidar"]
        robot_obs = obs["robot"]
        info = {}
        
        dist2goal = robot_obs[0]
        # Distances to LIDAR
        centerLidar = self.lidar.max_range;
        obstacle_coords = np.argwhere(scanning == 1)
        if obstacle_coords.size > 0:
            # Eucledian Distance from the center to each detected obstacle
            dists_to_obstacles = np.linalg.norm(obstacle_coords - [centerLidar, centerLidar], axis=1)
            dists_to_obstacles = np.clip(dists_to_obstacles, 0, self.lidar.max_range) # Clip to max range
            dists_to_obstacles = np.power(dists_to_obstacles, 2) # Square the distances to emphasize closer obstacles
            
            min_obstacle_dist = np.min(dists_to_obstacles)
            mean_dists = np.mean(dists_to_obstacles)
        else:
            # If there are no obstacles in view, we assume the maximum safe distance
            min_obstacle_dist = -float(self.lidar.max_range)
            mean_dists = min_obstacle_dist

        reward = -0.5 if all(action!=0 for action in self._previous_actions) else -0.01
        reward -= (5*dist2goal)/self._map_diagonal
        reward -= mean_dists/self._map_diagonal
        reward -= mean_dists/self._map_diagonal
        reward += ((previous_dist2goal - dist2goal)/self._map_diagonal) * 5

        terminated = False
        if dist2goal < 1:
            terminated = True
            reward = 100.0  # Big success reward

        # Replace your reward calculation with:
        truncated = not terminated and (truncated or bool(self.steps >= self.max_steps))
        if truncated:
            reward -= 10.0
        
        
        return (scanning, robot_obs), reward, terminated, truncated, info
    
    def render(self):
        if self.render_mode != 'human': 
            return
            
        if not hasattr(self, "renderer"): 
            self.renderer = PygameRenderer(self.map, cell_size=self.cell_size)
            
        obs = self._get_observation()
        lidar_image = obs["lidar"] 
        
        self.renderer.handle_events()
        self.renderer.render(self.robot, self.lidar, lidar_image, self.goal_pos)

